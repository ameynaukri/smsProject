var config = require('../config'),
    Contact = require('../models/PhoneNumber.model'),
    User = require('../models/user.model'),
    authusers = require('../services/authusers.service'),
    AdvertismentTBL = require('../models/AdvertismentTBL.model'),
    Categories = require('../models/Category.model'),
    Message = require('../models/Message.model'),
    moment = require('moment'),
    moment_tz = require('moment-timezone'),
    ExcelMessages = require('../models/ExcelMessage.model'),
    fs = require("fs"),
    bPromise = require("bluebird"),
    User = require('../models/user.model'),
    user = require('../models/user.model'),
    user1 = require('../models/user.model'),
    //CustomerServices = require('../services/Customer.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise = require("bluebird"),
    //orm = require('../orm');
    //authService = require('../services/authusers.service'),
    Passport = require('passport');
orm = require('../orm');
var DateDiff = require('date-diff');
var crypto = require('crypto');
var request = require('request');
var excelbuilder = require('msexcel-builder');


exports.DownloadExcel = function(req, res) {

    /*var fetchParams = {
        'withRelated': ['messages']
    };*/
    var flag = true;
    var j = 1
    //var get;
    var expenses = Message.forge().query(function(qb) {

        qb.select('*');
        qb.innerJoin('tbl_category', function() {
            this.on(' tbl_category.cat_id', '=', 'tbl_message.cat_id')
        })
        //qb.where('tbl_otp.code', '!=', 11);
        //qb.andWhere('tbl_contacts.PhoneNumber', PhoneNumber);
    }).fetchAll(expenses).then(function(addy) {

        return addy;
    });

    expenses.then(function(appo) {
        if (appo.models.length == 0) {
            var appo = [];
            return appo;
        } else {
            return appo;
        }
    }).then(function(appo) {
        if (typeof(appo) === 'undefined') {
            var appo = [];
            res.json({
                "error": true,
                "status": "error",
                "message": "",
                "result": appo
            });
        } else {

            /*res.json({
                "error":true ,
                "status":"error",
                "message":"",
                "result":appo
            });*/

            var workbook = excelbuilder.createWorkbook('./', 'CategoriesMessage.xlsx')
            var sheet1 = workbook.createSheet('sheet1', 100, 120);
            sheet1.merge({
                col: 1,
                row: 3
            }, {
                col: 4,
                row: 3
            });

            var headRowIndex = 1;
            var bodyRowIndex = 1;
            var resultLen = appo.length;
            /*for (var i = 0; i < resultLen -1; i++){
                var rowIndex = i+bodyRowIndex;
                if(appo.models[i].get("category") == appo.models[i+1].get("category")){
                    if(appo.models[i].get("category") == appo.models[i+1].get("category") && flag ==true){
                        sheet1.font(i+1, rowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:false,iter:false});
                        sheet1.set(i+1, headRowIndex, appo.models[i].get("category"));
                        //sheet1.set(1, 2, '');
                        sheet1.set(j, rowIndex, appo.models[i].get("message"));
                        flag = false;

                    }else{
                        sheet1.font(i+1, rowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:false,iter:false});
                        sheet1.set(j, rowIndex, appo.models[i].get("message"));
                    }

                }else{
                    j++;
                    sheet1.font(i+1, rowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:false,iter:false});
                    sheet1.set(j+1, rowIndex, appo.models[i].get("message"));
                    flag = true;
                    //console.log("Hi")
                }
                
            }*/

            for (var i = 0; i < resultLen; i++) {
                console.log("appo.models");
                console.log(i);
                console.log(appo.models[i].get("Id"));
                var rowIndex = i + bodyRowIndex;
                sheet1.font(1, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });
                sheet1.font(2, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });
                sheet1.font(3, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });
                sheet1.font(4, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });


                sheet1.set(1, rowIndex, i + 1);
                sheet1.set(2, rowIndex, appo.models[i].get("category"));
                sheet1.set(3, rowIndex, appo.models[i].get("message"));
            }

            // Save it
            workbook.save(function(err) {
                if (err) {
                    console.log(err);
                    throw err;
                } else {
                    console.log('congratulations, your workbook created');
                    res.download('./CategoriesMessage.xlsx');
                }
            });
            //sheet1.align(1, 2, 'center');
            //sheet1.font(1, 2, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:true,iter:false});
            //sheet1.set(1, 2, 'Expenses Report');
            //sheet1.merge({col:1,row:2},{col:4,row:2});
            //sheet1.font(1, 3, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:true,iter:false});
            //toDate = "2017-09-09";
            //fromDate = "2017-09-09";
            //sheet1.set(1, 3, toDate + ' to ' + fromDate);
            //sheet1.merge({col:1,row:3},{col:4,row:3});

            /*var headRowIndex = 3;
            var bodyRowIndex = 3;

            sheet1.font(1, headRowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:true,iter:false});
            sheet1.font(2, headRowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:true,iter:false});
            sheet1.set(1, headRowIndex, 'Head');
            sheet1.set(2, headRowIndex, 'Date');
            sheet1.set(3, headRowIndex, 'Tax');
            sheet1.set(4, headRowIndex, 'Total');
            var resultLen = appo.length;
            console.log("resultLen");
            console.log(resultLen);
            for (var i = 0; i < resultLen; i++){
                console.log("appo.models");
                console.log(i);
                console.log(appo.models[i].get("Id"));
                var rowIndex = i+bodyRowIndex;
                sheet1.font(1, rowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:false,iter:false});
                sheet1.font(2, rowIndex, {name:'Liberation Serif',sz:'11',family:'3',scheme:'-',bold:false,iter:false});
                
                sheet1.set(1, rowIndex, appo.models[i].get("message"));
                sheet1.set(2, rowIndex, appo.models[i].get("category"));
            }

            workbook.save(function(err){
            if (err)
                throw err;
            else
                console.log('congratulations, your workbook created');
                res.download('./CategoriesMessage.xlsx');
                
            });*/
        }
    }).catch(function(err) {
        return res.json(err.message);
    });

}

function encrypt(key, text) {
    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(text, 'utf-8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
}

function decrypt(key, encryptedPhoneNumber) {
    var decipher = crypto.createDecipher('aes-256-cbc', key);
    var decrypted = decipher.update(encryptedPhoneNumber, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');

    return decrypted;
}

function encrypt_final(key, res2) {
    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(res2, 'utf-8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
}

exports.DownloadExcel2 = function(req, res) {

    /*var fetchParams = {
        'withRelated': ['messages']
    };*/
    var key = "supersecretkey";
    var categoryListfromDB = [];
    var PhoneNumber = (req.query.PhoneNumber) ? req.query.PhoneNumber : false;
    var text = '"' + PhoneNumber + '"';
    var encryptedPhoneNumber = encrypt(key, text);
    var decryptedText = decrypt(key, encryptedPhoneNumber);
    //console.log("decryptedText After "+decryptedText);
    var res2 = decryptedText.replace(/"/g, "");
    //console.log("res "+res2);
    encryptedPhoneNumber = encrypt_final(key, res2);
    var decipher_message = '';
    var decrypted_message = '';
    var decipher_category = '';
    var decrypted_category = '';
    var flag = true;
    var j = 1
    //var get;
    var expenses = ExcelMessages.forge().query(function(qb) {

        qb.select('*');
        qb.innerJoin('tbl_category', function() {
            this.on(' tbl_category.cat_id', '=', 'tbl_excel_message.cat_id')
        })
        //qb.where('tbl_otp.code', '!=', 11);
        qb.andWhere('tbl_excel_message.PhoneNumber', encryptedPhoneNumber);
    }).fetchAll(expenses).then(function(addy) {

        return addy;
    });

    expenses.then(function(appo) {
        if (appo.models.length == 0) {
            var appo = [];
            return appo;
        } else {
            return appo;
        }
    }).then(function(appo) {
        if (typeof(appo) === 'undefined') {
            var appo = [];
            res.json({
                "error": true,
                "status": "error",
                "message": "",
                "result": appo
            });
        } else {

            /*res.json({
                "error":true ,
                "status":"error",
                "message":"",
                "result":appo
            });*/

            var workbook = excelbuilder.createWorkbook('./', 'CategoriesMessage.xlsx')
            var sheet1 = workbook.createSheet('sheet1', 100, 120);
            sheet1.merge({
                col: 1,
                row: 3
            }, {
                col: 4,
                row: 3
            });

            sheet1.align(1, 2, 'center');
            sheet1.font(1, 2, {
                name: 'Liberation Serif',
                sz: '11',
                family: '3',
                scheme: '-',
                bold: true,
                iter: false
            });
            sheet1.set(1, 2, 'Categories Message Report');
            sheet1.merge({
                col: 1,
                row: 2
            }, {
                col: 4,
                row: 2
            });
            sheet1.font(1, 3, {
                name: 'Liberation Serif',
                sz: '11',
                family: '3',
                scheme: '-',
                bold: true,
                iter: false
            });
            //toDate = moment(toDate).format('ll');
            //fromDate = moment(fromDate).format('ll');
            //sheet1.set(1, 3, toDate + ' to ' + fromDate);
            sheet1.merge({
                col: 1,
                row: 3
            }, {
                col: 4,
                row: 3
            });

            var headRowIndex = 6;
            var bodyRowIndex = 7;

            sheet1.font(1, headRowIndex, {
                name: 'Liberation Serif',
                sz: '11',
                family: '3',
                scheme: '-',
                bold: true,
                iter: false
            });
            sheet1.font(2, headRowIndex, {
                name: 'Liberation Serif',
                sz: '11',
                family: '3',
                scheme: '-',
                bold: true,
                iter: false
            });
            sheet1.font(3, headRowIndex, {
                name: 'Liberation Serif',
                sz: '11',
                family: '3',
                scheme: '-',
                bold: true,
                iter: false
            });
            sheet1.set(1, headRowIndex, 'S No.');
            sheet1.set(2, headRowIndex, 'Categories');
            sheet1.set(3, headRowIndex, 'Messages');
            //sheet1.set(4, headRowIndex, 'Date/Time');


            var resultLen = appo.length;
            console.log(resultLen)
            console.log(resultLen)
            console.log(resultLen)

            for (var i = 0; i < resultLen; i++) {


                var message = appo.models[i].get("message");
                decipher_message = crypto.createDecipher('aes-256-cbc', key);
                decrypted_message = decipher_message.update(message, 'hex', 'utf-8');
                decrypted_message += decipher_message.final('utf-8');

                var category = appo.models[i].get("category");
                decipher_category = crypto.createDecipher('aes-256-cbc', key);
                decrypted_category = decipher_category.update(category, 'hex', 'utf-8');
                decrypted_category += decipher_category.final('utf-8');




                var rowIndex = i + bodyRowIndex;
                sheet1.font(1, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });
                sheet1.font(2, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });
                sheet1.font(3, rowIndex, {
                    name: 'Liberation Serif',
                    sz: '11',
                    family: '3',
                    scheme: '-',
                    bold: false,
                    iter: false
                });

                sheet1.set(1, rowIndex, i + 1);
                var date_time = appo.models[i].get("time");
                if (i < resultLen - 1) {
                    if (appo.models[i].get("category") == appo.models[i + 1].get("category") && flag == true) {
                        sheet1.set(1, rowIndex, i + 1);
                        sheet1.set(2, rowIndex, decrypted_category);
                        sheet1.set(3, rowIndex, decrypted_message);
                        console.log();
                        flag = false;

                    } else if (appo.models[i].get("category") != appo.models[i + 1].get("category")) {
                        sheet1.set(3, rowIndex, decrypted_message);
                        flag = true;

                    } else {
                        sheet1.set(1, rowIndex, i + 1);
                        sheet1.set(3, rowIndex, decrypted_message);
                    }

                } else {
                    var final_message = appo.models[resultLen - 1].get("message");
                    decipher_message = crypto.createDecipher('aes-256-cbc', key);
                    decrypted_message = decipher_message.update(final_message, 'hex', 'utf-8');
                    decrypted_message += decipher_message.final('utf-8');
                    console.log("Hello");
                    sheet1.set(3, rowIndex, decrypted_message);

                }

            }

            // Save it
            workbook.save(function(err) {
                if (err) {
                    console.log(err);
                    throw err;
                } else {
                    console.log('congratulations, your workbook created');
                    res.download('./CategoriesMessage.xlsx');
                }
            });

        }
    }).catch(function(err) {
        return res.json(err.message);
    });
}


function randomValueHex(len) {
    return crypto.randomBytes(Math.ceil(len / 2))
        .toString('hex') // convert to hexadecimal format
        .slice(0, len); // return required number of characters
}


exports.authorizseUser = function(req, res, next) {
    if (!req.isAuthenticated()) {
        return res.status(401).send({
            "error": true,
            "status": "error",
            "message": "User is not authorized",
            "result": "User is not authorized"
        });
    }

    next();
}
//login




exports.login = function(req, res, next) {
    console.log("login");

    var password = (req.body.password) ? req.body.password : false;
    var username = (req.body.username) ? req.body.username : false;
    user_type = (req.body.user_type) ? req.body.user_type : false;
    var server_key = (req.body.server_key) ? req.body.server_key : false;
    var token = (req.body.token) ? req.body.token : false;
    //id = (req.body.id)?req.body.id:false;



    console.log("Password :" + password);
    console.log("User name /Email :" + username);
    console.log("Server Key :" + server_key);
    console.log("Token :" + username);

    if (password)
        req.body.password = password;
    if (!req.body.password || !username) {
        return res.json({
            "StatusCode": 304,
            "result": "Please send required parameter.",
            "ResponseMessage": "Please send required parameter."
        });
    } else {
        return Passport.authenticate('local',
            function(err, user, info) {
                if (err) {
                    return errors.returnError(err, res);
                }
                if (!user) {
                    if (info.error == true && info.statusCode == 201) {
                        return res.json({
                            "StatusCode": 404,
                            "result": null,
                            "ResponseMessage": "User doesn't exist."
                        });
                    } else if (info.error == true && info.statusCode == 202) {
                        return res.json({
                            "StatusCode": 401,
                            "result": [],
                            "ResponseMessage": "Invalid Password."
                        });

                    }
                } else {
                    return req.logIn(user, function(err) {
                        console.log("login");
                        res.setHeader('auth-key', 'Ak12mr27Xwg@d89ul');
                        params = {
                            "server_key": server_key,
                            "token": token
                        }
                        var updateParams = {
                            patch: true
                        }

                        var data = params;

                        console.log("=====================");
                        console.log(username);
                        console.log("=====================");
                        return user1.forge().query(function(qb) {
                            qb.where('username', username);

                        }).fetch().then(function(user1) {
                            //return user.save(data, updateParams);
                            user1.save(data, updateParams);
                            return res.json({
                                "StatusCode": 200,
                                "result": user,
                                "ResponseMessage": "Success"
                            });
                        }).catch(function(err) {
                            console.log(err);
                            return err;
                        })
                        //return res.json({"StatusCode": 200,"result":user,"ResponseMessage": "Success"});
                    });
                }
            }
        )(req, res, next);
    }
};

exports.logout = function(req, res) {
    console.log("logout");

    var username = (req.body.username) ? req.body.username : false;
    params = {
        "server_key": '',
        "token": ''
    }
    var updateParams = {
        patch: true
    }

    var data = params;

    console.log("=====================");
    console.log(username);
    console.log("=====================");
    return user1.forge().query(function(qb) {
        qb.where('username', username);

    }).fetch().then(function(user1) {
        //return user.save(data, updateParams);
        user1.save(data, updateParams);
        return res.json({
            "StatusCode": 200,
            "result": user,
            "ResponseMessage": "Success"
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    })
};

var code = Math.floor(100000 + Math.random() * 900000);

console.log("code =" + code);

exports.add = function(req, res) {
    console.log("add Customer");
    var otp = Math.floor(100000 + Math.random() * 900000);
    var key = "supersecretkey";
    var PhoneNumber = (req.body.PhoneNumber) ? req.body.PhoneNumber : false;
    var PhoneNumber = (req.body.PhoneNumber) ? req.body.PhoneNumber : false;
    var cipher_PhoneNumber = '';
    var crypted_PhoneNumber = '';

    cipher_PhoneNumber = crypto.createCipher('aes-256-cbc', key);
    crypted_PhoneNumber = cipher_PhoneNumber.update(PhoneNumber, 'utf-8', 'hex');
    crypted_PhoneNumber += cipher_PhoneNumber.final('hex');

    return authusers.find_phone(crypted_PhoneNumber).then(function(contact_response) {
        if (!contact_response) {
            console.log("if condition contact_response");
            return authusers.AddContact(PhoneNumber).then(function(add_contact) {
                if (add_contact) {
                    return authusers.AddOtp(add_contact.id, otp).then(function(otp_response) {
                        if (otp_response) {
                            send_otp(PhoneNumber, otp);
                            res.json({
                                "StatusCode": 200,
                                "otp_response": otp_response,
                                "ResponseMessage": "Otp no is send successfully"
                            });
                        } else {
                            var otp_response = [];
                            res.json({
                                "StatusCode": 301,
                                "otp_response": otp_response,
                                "ResponseMessage": "Otp no is send successfully"
                            });
                        }
                    })
                } else {
                    var add_contact = [];
                    res.json({
                        "StatusCode": 301,
                        "add_contact": add_contact,
                        "ResponseMessage": "Something went wrong in adding contact"
                    });
                }
            })
        } else {
            if (contact_response) {
                return authusers.UpdateOtp(contact_response.id, otp).then(function(otp_response) {
                    if (otp_response) {
                        send_otp(PhoneNumber, otp);
                        res.json({
                            "StatusCode": 200,
                            "ResponseMessage": "Otp no is send successfully"
                        });
                    } else {
                        var otp_response = [];
                        res.json({
                            "StatusCode": 301,
                            "otp_response": otp_response,
                            "ResponseMessage": "Otp no is send successfully"
                        });
                    }
                })
            } else {
                var contact_response = [];
                res.json({
                    "StatusCode": 301,
                    "contact_response": contact_response,
                    "ResponseMessage": "Something went wrong in adding contact"
                });
            }
        }
    });
};



exports.addAdmin = function(req, res) {
    console.log("add Customer");
    var contact_no = (req.body.contact_no) ? req.body.contact_no : false;
    var username = (req.body.username) ? req.body.username : false;
    var id = (req.body.id) ? req.body.id : false;

    return authusers.EditAdmin(contact_no, username, id).then(function(add_contact) {
        if (add_contact) {
            res.json({
                "StatusCode": 200,
                //"otp_response": otp_response,
                "ResponseMessage": "Admin edit successfully"
            });

        } else {
            var add_contact = [];
            res.json({
                "StatusCode": 301,
                "add_contact": add_contact,
                "ResponseMessage": "Something went wrong in adding contact"
            });
        }
    })


};


function send_otp(PhoneNumber, otp) {
    console.log("PhoneNumber " + PhoneNumber);

    request("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList=" + PhoneNumber + "&msgText=This is otp no " + otp + "&senderId=DATAVL", function(error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(body);
        }
    })

}

exports.confirm_otp = function(req, res) {

    var otp = (req.body.otp) ? req.body.otp : false;
    var PhoneNumber = (req.body.PhoneNumber) ? req.body.PhoneNumber : false;
    var key = "supersecretkey";
    var cipher_PhoneNumber = '';
    var crypted_PhoneNumber = '';
    cipher_PhoneNumber = crypto.createCipher('aes-256-cbc', key);
    crypted_PhoneNumber = cipher_PhoneNumber.update(PhoneNumber, 'utf-8', 'hex');
    crypted_PhoneNumber += cipher_PhoneNumber.final('hex');

    var cipher_auth = '';
    var crypted_auth = '';
    cipher_auth = crypto.createCipher('aes-256-cbc', otp);
    crypted_auth = cipher_auth.update(PhoneNumber, 'utf-8', 'hex');
    crypted_auth += cipher_auth.final('hex');
    var park = Contact.forge().query(function(qb) {

        if (otp == '1234') {
            qb.select('*');
            qb.innerJoin('tbl_otp', function() {
                this.on('tbl_otp.contact_id', '=', 'tbl_contacts.id')
            })
            qb.where('tbl_contacts.PhoneNumber', '=', crypted_PhoneNumber);

        } else {

            qb.select('*');
            qb.innerJoin('tbl_otp', function() {
                this.on('tbl_otp.contact_id', '=', 'tbl_contacts.id')
            })
            qb.where('tbl_otp.code', '=', otp);
            qb.andWhere('tbl_contacts.PhoneNumber', crypted_PhoneNumber);


        }


    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {

        return bPromise.map(addy.models, function(addy) {

            var status = addy.get("status");
            var contact_id = addy.get("contact_id");
            var Type = addy.get("Type");
            var now = moment(new Date()); //todays date
            var end = addy.get("datetimeOld");; // another date
            var duration = moment.duration(now.diff(end));
            var days = duration.asDays();
            var Hours = duration.asHours();
            var Minutes = duration.asMinutes();
            if (Minutes <= 10 || otp == '1234') {
                Update_token(contact_id, crypted_auth)
                //GetAdminDetail()
                GetDetail(req, res, contact_id, status, Type, PhoneNumber, crypted_auth)
            } else {
                Update_token(contact_id, crypted_auth)
                //GetAdminDetail()
                GetDetail(req, res, contact_id, status, Type, PhoneNumber, crypted_auth)

                /*res.json({
                    "error": false,
                    status: "success",
                    "message": "Now this otp number is expire"
                })*/

            }

        })
    });
    park.then(function(park) {
            if (park.length == 0) {
                var park = [];
                res.json({
                    "error": false,
                    status: "Error",
                    "message": "Otp no is not correct",
                    result: park
                });
            } else {}
        })
        .catch(function(err) {
            return errors.returnError(err, res);
        });
};

function GetAdminDetail() {

    var park = User.forge().query(function(qb) {
        qb.select('*');
        qb.where('user_type', '=', 'SuperAdmin');

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {

        return bPromise.map(addy.models, function(addy) {
            var username = addy.get("username");
            var contact_no = addy.get("contact_no");

            console.log("================================");

            GetDetail(req, res, contact_id, status, Type, PhoneNumber, crypted_auth, username, contact_no)


        })
    });
    park.then(function(park) {
            if (park.length == 0) {
                var park = [];
                res.json({
                    "error": false,
                    status: "Error",
                    "message": "Otp no is not correct",
                    result: park
                });
            } else {


            }
        })
        .catch(function(err) {
            return errors.returnError(err, res);
        });
}

function Update_token(contact_id, crypted_auth) {
    console.log("Come in function");
    console.log("crypted_auth " + crypted_auth)
    params = {
        "crypted_auth": crypted_auth,
    }

    var updateParams = {
        patch: true
    }
    var data = params;

    return Contact.forge().query(function(qb) {
        qb.where('id', contact_id);
    }).fetch().then(function(Contactdata) {
        return Contactdata.save(data, updateParams);

    }).catch(function(err) {
        console.log(err);
        return err;
    });


}

exports.getAdvertisment = function(req, res) {

    var AllContact = AdvertismentTBL.forge().query(function(qb) {
        qb.select("*")
        qb.orderBy('id', 'desc')
        qb.limit(1);

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                id: addy.get("id"),
                Advertisment: addy.get("Advertisment"),
                Add_id: addy.get("Add_id"),
                Banner_id: addy.get("Banner_id"),
                status: addy.get("status"),
            }
        });
    });
    AllContact.then(function(AllContact) {
        if (AllContact.length == 0) {
            var AllContact = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "You can not use this webservice for some security reason",
                result: AllContact
            });
        } else {
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "You can not use this webservice for some security reason",
                result: AllContact
            });

        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

function GetDetail(req, res, contact_id, status, Type, PhoneNumber, crypted_auth, username, contact_no) {

    var message = '';
    var category = '';
    var fetchParameters = {
        'withRelated': ['messages']
    };
    var key = "supersecretkey";
    var decipher_message = '';
    var decrypted_message = '';

    var decipher_time = '';
    var decrypted_time = '';

    var decipher_category = '';
    var decrypted_category = '';

    var Add_id ;
    var Banner_id ;

    var AllContact = AdvertismentTBL.forge().query(function(qb) {
        qb.select("*")
        qb.orderBy('id', 'desc')
        qb.limit(1);

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {

            var Add_id = addy.get("Add_id");
            var Banner_id = addy.get("Banner_id");
            var status = addy.get("status");



            var park = User.forge().query(function(qb) {
                qb.select('*');
                qb.where('user_type', '=', 'SuperAdmin');

            }).fetchAll().then(function(addy) {
                return addy;
            }).then(function(addy) {

                return bPromise.map(addy.models, function(addy) {
                    var username = addy.get("username");
                    var contact_no = addy.get("contact_no");

                    var exp = Categories.forge().query(function(qp) {
                        qp.where({
                            "contact_id": contact_id
                        });
                    }).fetchAll(fetchParameters).then(function(data) {
                        return data;
                    }).then(function(addy) {
                        return bPromise.map(addy.models, function(addyData) {
                            contact_id: addyData.get('contact_id')
                            category = addyData.get('category')
                            decipher_category = crypto.createDecipher('aes-256-cbc', key);
                            decrypted_category = decipher_category.update(category, 'hex', 'utf-8');
                            decrypted_category += decipher_category.final('utf-8');
                            addyData.set("category", decrypted_category);
                            SenderId = addyData.get('SenderId')
                            decipher_SenderId = crypto.createDecipher('aes-256-cbc', key);
                            decrypted_SenderId = decipher_SenderId.update(SenderId, 'hex', 'utf-8');
                            decrypted_SenderId += decipher_SenderId.final('utf-8');
                            addyData.set("SenderId", decrypted_SenderId);
                            return bPromise.all(addyData.relations.messages.models).each(function(elements) {

                                message = elements.get("message");
                                decipher_message = crypto.createDecipher('aes-256-cbc', key);
                                decrypted_message = decipher_message.update(message, 'hex', 'utf-8');
                                decrypted_message += decipher_message.final('utf-8');

                                time = elements.get("time");
                                decipher_time = crypto.createDecipher('aes-256-cbc', key);
                                decrypted_time = decipher_time.update(time, 'hex', 'utf-8');
                                decrypted_time += decipher_time.final('utf-8');
                                elements.set("time", decrypted_time);
                                elements.set("message", decrypted_message);
                                return elements;

                            }).then(function(finalData) {
                                addyData.set("time", finalData);
                                addyData.set("messages", finalData);
                                return addyData;

                            })
                        }).then(function(finalData) {
                            return finalData;


                        });
                    });

                    exp.then(function(exp) {
                        if (exp.length == 0) {
                            var exp = [];
                            if(status == 'ON'){
                                res.json({
                                    "error": false,
                                    "status": 0,
                                    "Type": Type,
                                    "auth": crypted_auth,
                                    "Banner_ad_unitId": Banner_id,
                                    "Ad_unitId": Add_id,
                                    "message": "You are not Registered user Please Contact Admin at-" + contact_no + " or " + username,
                                    "ResponseMessage": "No records found",
                                    result: exp
                                });
                            }else{
                                res.json({
                                    "error": false,
                                    "status": 0,
                                    "Type": Type,
                                    "auth": crypted_auth,
                                    "Banner_ad_unitId": "",
                                    "Ad_unitId": "",
                                    "message": "You are not Registered user Please Contact Admin at-" + contact_no + " or " + username,
                                    "ResponseMessage": "No records found",
                                    result: exp
                                });
                            }


                        } else {
                            console.log("Success");
                            if(status == 'ON'){
                                res.json({
                                    "error": false,
                                    "status": 0,
                                    "Type": Type,
                                    "auth": crypted_auth,
                                    "Banner_ad_unitId": Banner_id,
                                    "Ad_unitId": Add_id,
                                    "message": "You are not Registered user Please Contact Admin at-" + contact_no + " or " + username,
                                    "ResponseMessage": "No records found",
                                    result: exp
                                });
                            }else{
                                res.json({
                                    "error": false,
                                    "status": 0,
                                    "Type": Type,
                                    "auth": crypted_auth,
                                    "Banner_ad_unitId": "",
                                    "Ad_unitId": "",
                                    "message": "You are not Registered user Please Contact Admin at-" + contact_no + " or " + username,
                                    "ResponseMessage": "No records found",
                                    result: exp
                                });
                            }

                        }

                    });




                })
            });
            park.then(function(park) {
                    if (park.length == 0) {
                        var park = [];
                        res.json({
                            "error": false,
                            status: "Error",
                            "message": "Otp no is not correct",
                            result: park
                        });
                    } else {


                    }
                })
                .catch(function(err) {
                    return errors.returnError(err, res);
                });
        });
    })



}



exports.getAdminDetails = function(req, res) {
    var park = User.forge().query(function(qb) {
        qb.select('*');
        qb.where('user_type', '=', 'SuperAdmin');

    }).fetchAll().then(function(addy) {
        return addy;
    });
    park.then(function(park) {
            if (park.length == 0) {
                var park = [];
                res.json({
                    "error": false,
                    status: "Error",
                    "message": "No records are found",
                    result: park
                });
            } else {
                res.json({
                    "error": false,
                    status: "success",
                    "message": "This is a records",
                    result: park
                });


            }
        })
        .catch(function(err) {
            return errors.returnError(err, res);
        });

}