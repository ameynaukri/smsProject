var config = require('../config'),
    Contact = require('../models/PhoneNumber.model'),
    Categories = require('../models/Category.model'),
    Message = require('../models/Message.model'),
    SendMessage = require('../models/SendMessage.model'),
    SendMessageService = require('../services/SendMessage.service'),
    User = require('../models/user.model'),
    adminServices = require('../services/admin.service'),
    moment = require('moment'),
    moment_tz = require('moment-timezone'),
    fs = require("fs"),
    bPromise = require("bluebird"),
    orm = require('../orm');
var DateDiff = require('date-diff');
var crypto = require('crypto');
var request = require('request');
var http = require('http');

var secu = 0;


function check_auth(req, res, auth, array_tonumber, message, number, crypted_number) {

    var AllContact = Contact.forge().query(function(qb) {
        qb.select("*")
        qb.where({
            "crypted_auth": auth
        });

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                PhoneNumber: addy.get("PhoneNumber"),
                id: addy.get("id")
            }
        });
    });

    AllContact.then(function(AllContact) {
        if (AllContact.length == 0) {
            secu = 1;
            var AllContact = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "You can not use this webservice for some security reason",
                //result: AllContact
            });
        } else {
            secu = 1;


        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

exports.SendMessage = function(req, res) {

    var auth = (req.body.auth)?req.body.auth:false;
    check_auth(req, res, auth)
    var key = "supersecretkey";
    var number = (req.body.number) ? req.body.number : false;
    var cipher_number = ''; 
    var crypted_number = '';
    cipher_number = crypto.createCipher('aes-256-cbc', key);
    crypted_number = cipher_number.update(number, 'utf-8', 'hex');
    crypted_number += cipher_number.final('hex');
    var tonumber = (req.body.tonumber) ? req.body.tonumber : false;
    var message = (req.body.message) ? req.body.message : false;
    var s = tonumber;
    var match = s.split(', ')
    console.log(match)
    //var b = "[" +tonumber +"]";
    var array_tonumber = JSON.parse("[" + tonumber + "]");
    console.log("secu "+secu);
    if(secu == 1){
        return SendMessageService.find(crypted_number).then(function(data) {
        console.log("number "+number);
        if (data) {
            console.log("userData.PhoneNumber "+data.id)
            return SendMessageService.SendMessage_Insert(array_tonumber,message,data.id,number).then(function(CustomersData) {
                    if (CustomersData) {
                        res.json({
                            "StatusCode": 200,
                            "ResponseMessage": "Message is send successfully!"
                        });
                    
                    }else {
                        res.json({
                            "StatusCode": 301,
                            "ResponseMessage": "An error has occurred."
                        });
                    }
               
                })
        }else{
            res.json({
                "StatusCode": 201,
                "ResponseMessage": "This is user is not exists"
            });

        }
    }).catch(function(err) {
            throw err;
       });


    }
    

    

}

exports.SendMessage_Insert = function(req, res) {
    var auth = (req.body.auth) ? req.body.auth : false;
    var number = (req.body.number) ? req.body.number : false;
    var tonumber = (req.body.tonumber) ? req.body.tonumber : false;
    var message = (req.body.message) ? req.body.message : false;
    var s = tonumber;
    var match = s.split(', ')
    console.log(match)
    //var b = "[" +tonumber +"]";
    var array_tonumber = JSON.parse("[" + tonumber + "]");
    check_auth(req, res, auth, array_tonumber, message, number)

    return SendMessageService.find(number).then(function(data) {
        console.log("number " + number);
        if (data) {
            console.log("userData.PhoneNumber " + data.id)
            return SendMessageService.SendMessage_Insert(array_tonumber, message, data.id, number).then(function(CustomersData) {
                if (CustomersData) {
                    res.json({
                        "StatusCode": 200,
                        "ResponseMessage": "Message is send successfully!"
                    });

                } else {
                    res.json({
                        "StatusCode": 301,
                        "ResponseMessage": "An error has occurred."
                    });
                }

            })
        } else {
            res.json({
                "StatusCode": 201,
                "ResponseMessage": "This is user is not exists"
            });

        }
    }).catch(function(err) {
        throw err;
    });

}