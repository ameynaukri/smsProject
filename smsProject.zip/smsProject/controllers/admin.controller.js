var config = require('../config'),
    Contact = require('../models/PhoneNumber.model'),
    Categories = require('../models/Category.model'),
    Message = require('../models/Message.model'),
    User = require('../models/user.model'),
    adminServices = require('../services/admin.service'),
    heplerServices = require('../services/helper.service'),
    moment = require('moment'),
    moment_tz = require('moment-timezone'),
    fs = require("fs"),
    bPromise = require("bluebird"),
    orm = require('../orm');
var DateDiff = require('date-diff');
var crypto = require('crypto');
var request = require('request');
var LocalStrategy = require('passport-local').Strategy;
var Passport = require('passport');




exports.add_Details = function(req, res) {
    var key = "supersecretkey";
    var categoryListfromDB = [];
    var PhoneNumber = (req.body.PhoneNumber)?req.body.PhoneNumber:false;
    var text = '"'+ PhoneNumber +'"';
    var encryptedPhoneNumber = encrypt(key, text);
    var decryptedText = decrypt(key, encryptedPhoneNumber);
    var auth = (req.body.auth)?req.body.auth:false;
    check_auth(req, res, auth)
           
    //console.log("decryptedText After "+decryptedText);
    var res2 = decryptedText.replace(/"/g, "");
    //console.log("res "+res2);
    encryptedPhoneNumber = encrypt_final(key, res2);
    //console.log("encryptedPhoneNumber------------------ "+encryptedPhoneNumber);

    return adminServices.find(encryptedPhoneNumber).then(function(userData) {
        if (userData) {
            return adminServices.find_cat(userData.id).then(function(catData) {
                if (catData) {
                    return bPromise.all(catData.models).each(function(elements) {
                        categoryListfromDB.push(elements.get("SenderId"));
                        return elements;
                    }).then(function(data) {
                        return categoryListfromDB;
                    }).then(function(data) {
                        return adminServices.addCatDetails(userData.id, req.body.MessageData, categoryListfromDB).then(function(catDetails) {
                            if (catDetails) {
                                res.json({
                                    "StatusCode": 200,
                                    //"catDetails": catDetails,
                                    "ResponseMessage": "Cat Details successfully added !!!"
                                });
                            } else {
                                res.json({
                                    "StatusCode": 301,
                                    "ResponseMessage": "An error has occurred in Cat ."
                                });
                            }
                        });
                    }).catch(function(err) {
                        return err;
                    });

                } else {
                    // console.log("Else loop");
                }
            });
        } else {
            return adminServices.addPhoneNumber(encryptedPhoneNumber).then(function(details) {
                if (details) {
                    return adminServices.NewAddCatDetails(details.id, req.body.MessageData).then(function(catDetails) {
                        if (catDetails) {
                            res.json({
                                "StatusCode": 200,
                                //"catDetails": catDetails,
                                "ResponseMessage": "Cat Details successfully added !!!"
                            });
                        } else {
                            res.json({
                                "StatusCode": 301,
                                "ResponseMessage": "An error has occurred in Cat ."
                            });
                        }
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            }).catch(function(err) {
                throw err;
            });
        }
    });
}

function check_auth(req, res, auth) {    

    var AllContact = Contact.forge().query(function(qb) {
        qb.select("*")
        qb.where({
            "crypted_auth": auth
        });

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                PhoneNumber: addy.get("PhoneNumber"),
                id: addy.get("id")
            }
        });
    });

    AllContact.then(function(AllContact) {
        if (AllContact.length == 0) {
            var AllContact = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "You can not use this webservice for some security reason",
                //result: AllContact
            });
        } else {
            
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

exports.allShowHide = function(req, res) {
    var id = (req.query.id)?req.query.id : false;
    var status = (req.query.status)?req.query.status : false;
    return adminServices.findAdvertisement().then(function(userData) {
        if (userData) {
        return adminServices.allShowHide(userData.id, status).then(function(result) {
            if (result){
                res.json({
                    "StatusCode": 200,
                    "result": result,
                    "ResponseMessage ": "Record is updated succesfully"
                });
            } else {
                res.json({
                    "StatusCode": 200,
                    "result": result,
                    "ResponseMessage": "An error has occurred."
                });
            }
        })
     } else {
            res.json({
                "StatusCode": 301,
                "ResponseMessage": "An error has occurred in Cat ."
            });
        }
    });
}




exports.editadvertisment = function(req, res) {
    return adminServices.editadvertisment(req.body).then(function(result) {
        res.json({
            "StatusCode": 200,
            "result": result,
            "ResponseMessage ": "Record is updated succesfully"
        });
    })
}


function encrypt(key, text) {
        var cipher = crypto.createCipher('aes-256-cbc', key);
        var crypted = cipher.update(text, 'utf-8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
}

function decrypt(key, encryptedPhoneNumber) {
        var decipher = crypto.createDecipher('aes-256-cbc', key);
        var decrypted = decipher.update(encryptedPhoneNumber, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');

        return decrypted;
}

function encrypt_final(key, res2) {
        var cipher = crypto.createCipher('aes-256-cbc', key);
        var crypted = cipher.update(res2, 'utf-8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
}
var PhoneNumber ="9754845046";
console.log(config.server.web_uri+"/DownloadExcel2?PhoneNumber="+PhoneNumber);

exports.add_to_excel = function(req, res) {
    var auth = (req.body.auth)?req.body.auth:false;
    check_auth(req, res, auth)
    var key = "supersecretkey";
    var categoryListfromDB = [];
    var PhoneNumber = (req.body.PhoneNumber)?req.body.PhoneNumber:false;
    var text = '"'+ PhoneNumber +'"';
    var encryptedPhoneNumber = encrypt(key, text);
    var decryptedText = decrypt(key, encryptedPhoneNumber);
    console.log("decryptedText After "+decryptedText);
    var res2 = decryptedText.replace(/"/g, "");
    console.log("res "+res2);
    encryptedPhoneNumber = encrypt_final(key, res2);
    console.log("encryptedPhoneNumber------------------ "+encryptedPhoneNumber);
    return adminServices.find(encryptedPhoneNumber).then(function(userData) {
        if (userData) {
            return adminServices.find_cat(userData.id).then(function(catData) {
                if (catData) {
                    return bPromise.all(catData.models).each(function(elements) {
                        categoryListfromDB.push(elements.get("SenderId"));
                        return elements;
                    }).then(function(data) {
                        return categoryListfromDB;
                    }).then(function(data) {
                        return adminServices.ExcelAddCatDetails(encryptedPhoneNumber,userData.id, req.body.MessageData, categoryListfromDB).then(function(catDetails) {
                            if (catDetails) {
                                res.json({
                                    "StatusCode": 200,
                                    "catDetails": catDetails,
                                    "url" : config.server.web_uri+"/DownloadExcel2?PhoneNumber="+PhoneNumber,
                                    //"url" : "http://192.168.1.29:3016/DownloadExcel2?PhoneNumber=8871849350",
                                    "ResponseMessage": "Cat Details successfully added !!!"
                                });
                            } else {
                                res.json({
                                    "StatusCode": 301,
                                    "ResponseMessage": "An error has occurred in Cat ."
                                });
                            }
                        });
                    }).catch(function(err) {
                        return err;
                    });

                } else {
                    // console.log("Else loop");
                }
            });
        } else {
            return adminServices.addPhoneNumber(encryptedPhoneNumber).then(function(details) {
                if (details) {
                    return adminServices.ExcelNewAddCatDetails(encryptedPhoneNumber,details.id, req.body.MessageData).then(function(catDetails) {
                        if (catDetails) {
                            res.json({
                                "StatusCode": 200,
                                "catDetails": catDetails,
                                "url" : config.server.web_uri+"/DownloadExcel2?PhoneNumber="+PhoneNumber,
                                //"url" : "http://192.168.1.29:3016/DownloadExcel2?PhoneNumber=8871849350",
                                "ResponseMessage": "Cat Details successfully added !!!"
                            });
                        } else {
                            res.json({
                                "StatusCode": 301,
                                "ResponseMessage": "An error has occurred in Cat ."
                            });
                        }
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            }).catch(function(err) {
                throw err;
            });
        }
    });
}


exports.addAddvertisment = function(req, res) {
    var Advertisment = (req.body.Advertisment) ? req.body.Advertisment : false;
    var Add_id = (req.body.Add_id) ? req.body.Add_id : false;
    var Banner_id = (req.body.Banner_id) ? req.body.Banner_id : false;

    return adminServices.addAddvertisment(req.body).then(function(regDetail) {
        if (regDetail) {

            res.json({
                "StatusCode": 200,
                "regDetail": regDetail,
                "ResponseMessage": "Advertisment added successfully !!!"
            });
        } else {
            res.json({
                "StatusCode": 301,
                "regDetail": regDetail,
                "ResponseMessage": "An error has occurred."
            });
        }
    }).catch(function(err) {
        throw err;
    });
}

exports.addReg = function(req, res) {
    var key = "supersecretkey";
    var PhoneNumber = (req.body.PhoneNumber)?req.body.PhoneNumber:false;
    var text = '"'+ PhoneNumber +'"';
    var encryptedPhoneNumber = encrypt(key, text);
    var decryptedText = decrypt(key, encryptedPhoneNumber);
    console.log("decryptedText After "+decryptedText);
    var res2 = decryptedText.replace(/"/g, "");
    console.log("res "+res2);
    encryptedPhoneNumber = encrypt_final(key, res2);
    console.log("encryptedPhoneNumber------------------ "+encryptedPhoneNumber);
    return adminServices.duplicateMobile(encryptedPhoneNumber).then(function(dupData) {
        if (!dupData) {
            return adminServices.addReg(req.body,encryptedPhoneNumber).then(function(regDetail) {
                if (regDetail) {

                    res.json({
                        "StatusCode": 200,
                        "regDetail": regDetail,
                        "ResponseMessage": "Registration done successfully !!!"
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "regDetail": regDetail,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            });
        } else {

            return adminServices.UpdateReg(req.body,encryptedPhoneNumber).then(function(regDetail) {
                if (regDetail) {
                    res.json({
                        "StatusCode": 200,
                        "regDetail": regDetail,
                        "ResponseMessage": "Registration done successfully !!!"
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "regDetail": regDetail,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            });
            
        }
    }).catch(function(err) {
        throw err;
    });
}


exports.getAllRecords = function(req, res) {

    //console.log("getAllRecords---------------");
    var PhoneNumber ='';
    var key = "supersecretkey";
    var decipher_PhoneNumber = ''; 
    var decrypted_PhoneNumber = '';


    var AllContact = Contact.forge().query(function(qb) {
        qb.select("*")
        qb.groupBy('PhoneNumber');

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            //var PhoneNumber = addy.get("PhoneNumber");
            PhoneNumber = addy.get("PhoneNumber");
            console.log("PhoneNumber "+PhoneNumber);
            decipher_PhoneNumber = crypto.createDecipher('aes-256-cbc', key);
            decrypted_PhoneNumber = decipher_PhoneNumber.update(PhoneNumber, 'hex', 'utf-8');
            decrypted_PhoneNumber += decipher_PhoneNumber.final('utf-8');

                console.log("decrypted "+decrypted_PhoneNumber);
            return {
                PhoneNumber: decrypted_PhoneNumber,
                id: addy.get("id")
            }
        });
    });

    AllContact.then(function(AllContact) {
        if (AllContact.length == 0) {
            var AllContact = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: AllContact
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: AllContact
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}


exports.getCategoryMessage = function(req, res) {
    var id = (req.params.id) ? req.params.id : false;
    var message ='';
    var category ='';
    var fetchParameters = {
        'withRelated': ['messages']
    };
    var key = "supersecretkey";
    var decipher_message = ''; 
    var decrypted_message = '';

    var decipher_time = ''; 
    var decrypted_time = '';

    var decipher_category = ''; 
    var decrypted_category= '';

    var exp =  Categories.forge().query(function(qp) {
        qp.where({
            "contact_id": id
        });
    }).fetchAll(fetchParameters).then(function(data) {
        return data;
        //res.json(data);   
    }).then(function(addy){
        return bPromise.map(addy.models, function(addyData){
            console.log("addyData.get('contact_id') "+addyData.get('contact_id'));
            contact_id : addyData.get('contact_id')
            category = addyData.get('category')
            decipher_category = crypto.createDecipher('aes-256-cbc', key);
            decrypted_category = decipher_category.update(category, 'hex', 'utf-8');
            decrypted_category += decipher_category.final('utf-8');
            addyData.set("category",decrypted_category);
            SenderId = addyData.get('SenderId')
            decipher_SenderId = crypto.createDecipher('aes-256-cbc', key);
            decrypted_SenderId = decipher_SenderId.update(SenderId, 'hex', 'utf-8');
            decrypted_SenderId += decipher_SenderId.final('utf-8');
            addyData.set("SenderId",decrypted_SenderId);
            return bPromise.all(addyData.relations.messages.models).each(function(elements) {
                
                console.log(elements.get("message"));
                //message = elements.get("message");
                //console.log("message "+message);
                message = elements.get("message");
                decipher_message = crypto.createDecipher('aes-256-cbc', key);
                decrypted_message = decipher_message.update(message, 'hex', 'utf-8');
                decrypted_message += decipher_message.final('utf-8');

                console.log("decrypted "+decrypted_message);
                console.log("=======================");
                time = elements.get("time");
                decipher_time = crypto.createDecipher('aes-256-cbc', key);
                decrypted_time = decipher_time.update(time, 'hex', 'utf-8');
                decrypted_time += decipher_time.final('utf-8');

                //console.log("decrypted "+decrypted_message);
                console.log("=======================");

                elements.set("time",decrypted_time);
                elements.set("message",decrypted_message);
                //elements.set("time",decrypted_message);
                return elements;
                /*return {
                    contact_id: addy.get('contact_id'),
                    messages: decrypted,
                } */
            }).then(function(finalData){
                addyData.set("time",finalData);
                addyData.set("messages",finalData);
                return addyData;

            })   
        }).then(function(finalData){
            return finalData;


        });
    });

    exp.then(function(exp){
        res.json(exp);
        
    });
}



exports.getCategory = function(req, res) {
    var id = (req.query.id) ? req.query.id : false;
    console.log(id);
    var AllCategories = Categories.forge().query(function(qb) {
        qb.select("*");
        qb.where('contact_id', '=', id)
        qb.groupBy('category');
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var category = addy.get("category");
            return {
                category: category,
                cat_id: addy.get("cat_id"),
            }
        });
    });

    getCategory.then(function(getCategory) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: getCategory
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "These are the records",
                result: getCategory
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

exports.getMessage = function(req, res) {

    //var cat_id = (req.query.cat_id) ? req.query.cat_id : false;
    var key = "supersecretkey";
    var decipher = ''; 
    var decrypted = '';
    var All_Message = Message.forge().query(function(qb) {
        qb.select("*");
        //qb.where('cat_id', '=', cat_id)
        qb.groupBy('message');
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var message = addy.get("message");
            decipher = crypto.createDecipher('aes-256-cbc', key);
            decrypted = decipher.update(message, 'hex', 'utf-8');
            decrypted += decipher.final('utf-8');
        

            return decrypted;
            return {
                message: decrypted,
                cat_id: addy.get("cat_id")
            }
        });
    });

    All_Message.then(function(All_Message) {
        if (All_Message.length == 0) {
            var All_Message = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: All_Message
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: All_Message
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}


exports.duplicateMobile = function(req, res) {
    return adminServices.duplicateMobile(req.body.PhoneNumber).then(function(dupData) {
        if (dupData) {
            res.json({
                "StatusCode": 301,
                "catDetails": dupData,
                "ResponseMessage": "number alreasy exits!!!"
            });
        } else {
            res.json({
                "StatusCode": 200,
                "catDetails": dupData,
                "ResponseMessage": "new number!!!"
            });
        }
    }).catch(function(err) {
        throw err;
    });
}