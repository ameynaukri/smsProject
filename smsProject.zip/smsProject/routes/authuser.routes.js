/**
 * Module dependencies
 */
var controller = require('../controllers/authuser.controller');
var middleware = require('../middlewares/AuthUser.middleware');
/**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {

    router.route('/add')
        .post(controller.add);
    router.route('/addAdmin')
        .post(controller.addAdmin);
    router.route('/confirm_otp')
        .post(controller.confirm_otp);
    router.route('/Login')
        .post(controller.login);
    router.route('/getAdminDetails')
        .get(controller.getAdminDetails);

        
    /* router.route('/profile_update')
         .post(controller.profile_update); */
    router.route('/getAdvertisment')
        .get(controller.getAdvertisment);
         
    router.route('/Logout')
        .post(controller.logout);
    router.route('/DownloadExcel')
        .get(controller.DownloadExcel);
    router.route('/DownloadExcel2')
        .get(controller.DownloadExcel2);    
    /*router.route('/Customer/Add')
        .post(controller.add); */    

    
}