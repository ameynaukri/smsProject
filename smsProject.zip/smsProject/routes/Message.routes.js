/**
 * Module dependencies
 */
var controller = require('../controllers/Message.controller');
/**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {

    router.route('/SendMessage')
        .post(controller.SendMessage);
    router.route('/SendMessage_Insert')
        .post(controller.SendMessage_Insert);    
    
}