/**
 * Module dependencies
 */
 var controller = require('../controllers/admin.controller');
// var middleware = require('../middlewares/AuthUser.middleware');
 /**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {
  
  router.route('/add_Details')
      .post(controller.add_Details);
  router.route('/add_to_excel')
      .post(controller.add_to_excel);
  router.route('/allShowHide')
      .post(controller.allShowHide);
  router.route('/getAllRecords')
      .get(controller.getAllRecords);
  router.route('/getCategoryMessage/:id')
      .get(controller.getCategoryMessage); 
  router.route('/getCategory')
      .get(controller.getCategory);
  router.route('/getMessage')
      .get(controller.getMessage); 
  router.route('/addReg')
      .post(controller.addReg);
  router.route('/addAddvertisment')
      .post(controller.addAddvertisment);
  router.route('/editadvertisment')
      .post(controller.editadvertisment);
  router.route('/duplicateMobile')
      .post(controller.duplicateMobile);                                                  
}


