var orm = require('../orm');
var Contact = orm.bookshelf.Model.extend({
	  tableName: 'tbl_contacts',
	  idAttribute: 'id',
	  Otps: function() { return this.hasMany(Otp, 'otp_id');
	},
});
Otp = require('./Otp.model');
module.exports = Contact;