var orm = require('../orm');

// Related Models


var Categories = orm.bookshelf.Model.extend({
	  tableName: 'tbl_category',
	  idAttribute: 'cat_id',
	  messages: function() { return this.hasMany(Message, 'cat_id');
	},
});
Message = require('./Message.model');
module.exports = Categories;