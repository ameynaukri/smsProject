var orm = require('../orm');

// Related Models

var Messages = orm.bookshelf.Model.extend({
	  tableName: 'tbl_message',
	  idAttribute: 'msgId'
});
module.exports = Messages;