var orm = require('../orm');

// Related Models

var Otp = orm.bookshelf.Model.extend({
	  tableName: 'tbl_otp',
	  idAttribute: 'otp_id'
});
module.exports = Otp;