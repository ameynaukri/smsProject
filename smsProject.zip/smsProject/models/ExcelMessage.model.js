var orm = require('../orm');

// Related Models

var ExcelMessages = orm.bookshelf.Model.extend({
	  tableName: 'tbl_excel_message',
	  idAttribute: 'msgId'
});
module.exports = ExcelMessages;