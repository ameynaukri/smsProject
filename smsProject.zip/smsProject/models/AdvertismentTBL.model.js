var orm = require('../orm');

// Related Models

var AdvertismentTBL = orm.bookshelf.Model.extend({
	  tableName: 'tbl_addvertisment',
	  idAttribute: 'id'
});
module.exports = AdvertismentTBL;