var Contact = require('../models/PhoneNumber.model'),
    Otp = require('../models/Otp.model'),
    User = require('../models/user.model'),
    moment = require('moment'),
    promise = require('bluebird'),
    helperServices = require('../services/helper.service'),
    errorTypes = require('../errortypes');
var crypto = require("crypto");

exports.find_phone = function(crypted_PhoneNumber){
    

    return Contact.forge().query(function (qb) {
        qb.where({"PhoneNumber":crypted_PhoneNumber});
    }).fetch(function(data){
        return data;
    }).catch(function(err){
        return err;
    })
} 


exports.AddContact = function(PhoneNumber) {
    var key = "supersecretkey";
    var cipher_PhoneNumber =  '';
    var crypted_PhoneNumber = '';

    cipher_PhoneNumber = crypto.createCipher('aes-256-cbc', key);
    crypted_PhoneNumber = cipher_PhoneNumber.update(PhoneNumber, 'utf-8', 'hex');
    crypted_PhoneNumber += cipher_PhoneNumber.final('hex');

    
    var Contacts = new Contact({
        PhoneNumber: crypted_PhoneNumber,
    });
    return Contacts.save(null).tap(function(model) {
        ContactData = model;
        return ContactData;
    }).then(function(ContactData) {
        return ContactData;
    }).catch(function(err) {
        return err;
    });
};

exports.AddOtp = function(contact_id ,otp) {
    var myDate = moment(new Date()).format("YYYY-MM-DD");
    var datetimeOld = new Date();
	console.log("OTP "+otp);
	console.log("contact_id "+contact_id);
    var Otps = new Otp({
        contact_id: contact_id,
        code: otp,
        datetimeOld: datetimeOld,

    });
    return Otps.save(null).tap(function(model) {
        OtpsData = model;
        return OtpsData;
    }).then(function(OtpsData) {
        return OtpsData;
    }).catch(function(err) {
        return err;
    });
};


exports.EditAdmin = function(contact_no,username,id) {
 /*   var Otps = new Otp({
        contact_no: contact_no,
        username: username,
        

    });
    return Otps.save(null).tap(function(model) {
        OtpsData = model;
        return OtpsData;
    }).then(function(OtpsData) {
        return OtpsData;
    }).catch(function(err) {
        return err;
    });
*/
    console.log("contact_no "+contact_no);
    console.log("id "+id);
    console.log("username "+username);
    params = {
        contact_no: contact_no,
        username: username,
    }
    var updateParams = {
        patch: true
    }

    var data = params;

    return User.forge().query(function(qb) {
        qb.where('id', id);

    }).fetch().then(function(User) {
        //return User;
        if(User){
            return User.save(data, updateParams);
        } else {
            //return exports.AddOtp(contact_id ,otp);
        }
    }).catch(function(err) {
        console.log(err);
        return err;
    });
};


exports.UpdateOtp = function(contact_id ,otp) {

    var myDate = moment(new Date()).format("YYYY-MM-DD");
    var datetimeOld = new Date();
	console.log("OTP "+otp);
	console.log("contact_id "+contact_id);
    params = {
        "code": otp,
        "datetimeOld": datetimeOld
    }
    var updateParams = {
        patch: true
    }

    var data = params;

    return Otp.forge().query(function(qb) {
        qb.where('contact_id', contact_id);

    }).fetch().then(function(Otp) {
        if(Otp){
            return Otp.save(data, updateParams);
        } else {
            return exports.AddOtp(contact_id ,otp);
        }
    }).catch(function(err) {
        console.log(err);
        return err;
    });
};