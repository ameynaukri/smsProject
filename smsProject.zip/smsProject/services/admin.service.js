var User = require('../models/user.model'),
    Contact = require('../models/PhoneNumber.model'),
    AdvertismentTBL = require('../models/AdvertismentTBL.model'),
    Categories = require('../models/Category.model'),
    Messages = require('../models/Message.model'),
    ExcelMessages = require('../models/ExcelMessage.model'),
    //tbl_excel_message
    heplerServices = require('../services/helper.service'),
    moment = require('moment');
var bPromise = require("bluebird");
var crypto = require("crypto");
var key = "supersecretkey";
exports.add = function(params, code) {
    var myDate = moment(new Date()).format("YYYY-MM-DD");
    var datetimeOld = new Date();

    var Customers = new User({
        code: code,
        date: myDate,
        datetimeOld: datetimeOld,

    });
    return Customers.save(null).tap(function(model) {
        CustomersData = model;
        return CustomersData;
    }).then(function(CustomersData) {
        return CustomersData;
    }).catch(function(err) {
        return err;
    });
};

//var key1 = "supersecretkey";
exports.addReg = function(params,encryptedPhoneNumber) {
    console.log("addReg");
    
    var PhoneNumber = (params.PhoneNumber) ? params.PhoneNumber : false;
    var FullName = (params.FullName) ? params.FullName : false;
    FullName = heplerServices.encryption(key,FullName);
    var LastName = (params.LastName) ? params.LastName : false;
    LastName = heplerServices.encryption(key,LastName);
    var MessageLimit = (params.MessageLimit) ? params.MessageLimit : false;
    //MessageLimit = heplerServices.encryption(key,MessageLimit);
    var StartDate = (params.StartDate) ? params.StartDate : false;
    StartDate = heplerServices.encryption(key,StartDate);
    var EndDate = (params.EndDate) ? params.EndDate : false;
    EndDate = heplerServices.encryption(key,EndDate);

    var Contactdata = new Contact({
        "FullName": FullName,
        "LastName": LastName,
        "MessageLimit": MessageLimit,
        "PhoneNumber": encryptedPhoneNumber,
        "StartDate": StartDate,
        "EndDate": EndDate,
        "Type": "1",
    });

    return Contactdata.save(null).tap(function(model) {
        Contactdata = model;
        return Contactdata;
    }).then(function(Contactdata) {
        return Contactdata;
    }).catch(function(err) {
        return err;
    });

}


exports.allShowHide = function(id, status) {
    var status = status;
    params = status;
    params = {
        "status": status
    }
    var updateParams = {
        patch: true
    }
    var data = params;
        return AdvertismentTBL.forge().query(function(qb) {
            qb.where('id', id);
        }).fetchAll().then(function(products) {
            products.forEach(function(products) {
            return products.save(data, updateParams);
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}
exports.addAddvertisment = function(params) {
    var Advertisment = (params.Advertisment) ? params.Advertisment : false;
    var Add_id = (params.Add_id) ? params.Add_id : false;
    var Banner_id = (params.Banner_id) ? params.Banner_id : false;

    var AdvertismentTBLdata = new AdvertismentTBL({
        "Add_id": Add_id,
        "Banner_id": Banner_id,
        "Advertisment": Advertisment,
    });

    return AdvertismentTBLdata.save(null).tap(function(model) {
        AdvertismentTBLdata = model;
        return AdvertismentTBLdata;
    }).then(function(AdvertismentTBLdata) {
        return AdvertismentTBLdata;
    }).catch(function(err) {
        return err;
    });

}


exports.editadvertisment = function(params) {
    var Advertisment = (params.Advertisment) ? params.Advertisment : false;
    var Add_id = (params.Add_id) ? params.Add_id : false;
    var Banner_id = (params.Banner_id) ? params.Banner_id : false;
    var id = (params.id) ? params.id : false;
    params = {
        "Advertisment": Advertisment,
        "Add_id": Add_id,
        "Banner_id": Banner_id,
    }
    var updateParams = {
        patch: true
    }
    var data = params;
        return AdvertismentTBL.forge().query(function(qb) {
            qb.where('id', id);
        }).fetchAll().then(function(products) {
            products.forEach(function(products) {
            return products.save(data, updateParams);
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

exports.UpdateReg = function(params,encryptedPhoneNumber) {
    var PhoneNumber = (params.PhoneNumber) ? params.PhoneNumber : false;
    params = {
        "FullName": (params.FullName) ? params.FullName : false,
        "LastName": (params.LastName) ? params.LastName : false,
        "MessageLimit": (params.MessageLimit) ? params.MessageLimit : false,
        //"PhoneNumber": (params.PhoneNumber) ? params.PhoneNumber : false,
        "StartDate": (params.StartDate) ? params.StartDate : false,
        "EndDate": (params.EndDate) ? params.EndDate : false,
        "Type": "1",
    }
    var updateParams = {
        patch: true
    }

    var data = params;

    return Contact.forge().query(function(qb) {
        qb.where('PhoneNumber', encryptedPhoneNumber);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}    


exports.addPhoneNumber = function(encryptedPhoneNumber) {
    
    var date = moment(new Date()).format("YYYY-MM-DD");
    var Type = 2;
    var PhoneNumberData = new Contact({
        "PhoneNumber": encryptedPhoneNumber,
        "Type": Type,
    });

    return PhoneNumberData.save(null).tap(function(PhoneNumberData) {
        return PhoneNumberData;
    }).then(function(PhoneNumberData) {
        return PhoneNumberData;
    }).catch(function(err) {
        return err;
    });
}



exports.addCatDetails = function(contact_id, MessageData, categoryListfromDB) {
    var cipher_message =  '';
    var crypted_message = '';
    var cipher_time =  '';
    var crypted_time = '';
    var cipher_category =  '';
    var crypted_category = '';
    var cipher_SenderId =  '';
    var crypted_SenderId = '';
    var encryptedText ='';


    var pro2 = JSON.parse(MessageData); //for service 
    //var pro2 = (MessageData);         //for service 
    console.log("==============pro2==================");
    console.log(pro2);
    console.log("==============pro2==================");
    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;
        cipher_SenderId = crypto.createCipher('aes-256-cbc', key);
        crypted_SenderId = cipher_SenderId.update(SenderId, 'utf-8', 'hex');
        crypted_SenderId += cipher_SenderId.final('hex');

        var indexOfArray = categoryListfromDB.indexOf(crypted_SenderId);
        if (indexOfArray > -1) {
            return Categories.forge().query(function(qb) {
                qb.where({
                    "SenderId": crypted_SenderId
                });
                qb.andWhere({
                    'contact_id': contact_id
                });
            }).fetch().then(function(data) {
                var cat_id = data.get("cat_id");
                //console.log("cat_id" + cat_id);
                //console.log("=====================================");
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                // console.log("=====================================");
                // console.log(a);
                // console.log("=====================================");
                // console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);
                    cipher_time = crypto.createCipher('aes-256-cbc', key);
                    crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                    crypted_time += cipher_time.final('hex');

                    return Messages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': crypted_time
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        cipher_message = crypto.createCipher('aes-256-cbc', key);
                        crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                        crypted_message += cipher_message.final('hex');

                        //console.log("cryptedcrypted"+crypted);
                        //return crypted;
                        //console.log("encryptedText ="+ crypted);
                        //if(a[index] =)
                        var MessagesData = new Messages({
                            "message": crypted_message,
                            "time": crypted_time,
                            "cat_id": cat_id,
                        });
                        return MessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });
            }).catch(function(err) {
                return err;
            })
        } else {

            cipher_category = crypto.createCipher('aes-256-cbc', key);
            crypted_category = cipher_category.update(category, 'utf-8', 'hex');
            crypted_category += cipher_category.final('hex');

            var catData = new Categories({
                "contact_id": contact_id,
                "category": crypted_category,
                "SenderId": crypted_SenderId
            });
            return catData.save(null).tap(function(model) {
                return model;
            }).then(function(data) {
                var cat_id = data.get("cat_id");
                //console.log("cat_id" + cat_id);
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                //console.log(a);
                //console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);
                    cipher_time = crypto.createCipher('aes-256-cbc', key);
                    crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                    crypted_time += cipher_time.final('hex');

                    return Messages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': crypted_time
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        cipher_message = crypto.createCipher('aes-256-cbc', key);
                        crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                        crypted_message += cipher_message.final('hex');

                        var MessagesData = new Messages({
                            "message": crypted_message,
                            "time": crypted_time,
                            "cat_id": cat_id,
                        });
                        return MessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });

            }).catch(function(err) {
                return err;
            });
        }


    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}


exports.NewAddCatDetails = function(contact_id, MessageData) {
    console.log("add Cat Details service");
    //var key = "supersecretkey";
    var cipher_message =  '';
    var crypted_message = '';
    var cipher_time =  '';
    var crypted_time = '';
    var cipher_category =  '';
    var crypted_category = '';
    var cipher_SenderId =  '';
    var crypted_SenderId = '';

    //var pro2 = JSON.parse(MessageData); //for service 
    var pro2 = (MessageData);         //for service 

    console.log("==============pro2==================");
    console.log(pro2);
    console.log("==============pro2==================");

    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;

        cipher_category = crypto.createCipher('aes-256-cbc', key);
        crypted_category = cipher_category.update(category, 'utf-8', 'hex');
        crypted_category += cipher_category.final('hex');

        cipher_SenderId = crypto.createCipher('aes-256-cbc', key);
        crypted_SenderId = cipher_SenderId.update(SenderId, 'utf-8', 'hex');
        crypted_SenderId += cipher_SenderId.final('hex');

        var catData = new Categories({
            "contact_id": contact_id,
            "category": crypted_category,
            "SenderId": crypted_SenderId
        });
        return catData.save(null).tap(function(model) {
            return model;
        }).then(function(data) {
            var cat_id = data.get("cat_id");
            var a = elements.messages;
            var b = elements.time;
            var c = a.concat(b);
            return bPromise.all(c).each(function(item, index) {
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                cipher_time = crypto.createCipher('aes-256-cbc', key);
                crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                crypted_time += cipher_time.final('hex');

                return Messages.forge().query(function(qb) {
                    qb.where({
                        "time": ''
                    });
                    qb.orWhere({
                        'time': crypted_time
                    });
                    qb.del();
                }).fetch().then(function(deleteData) {
                    cipher_message = crypto.createCipher('aes-256-cbc', key);
                    crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                    crypted_message += cipher_message.final('hex');

                    var MessagesData = new Messages({
                        "message": crypted_message,
                        "time": crypted_time,
                        "cat_id": cat_id,
                    });
                    return MessagesData.save(null).tap(function(model) {
                        return model;
                    }).then(function(data) {
                        return data;
                    })
                });

            }).then(function(data) {
                return data;
            });
        }).catch(function(err) {
            return err;
        });
    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}

exports.ExcelAddCatDetails = function(encryptedPhoneNumber,contact_id, MessageData, categoryListfromDB) {
    var cipher_message =  '';
    var crypted_message = '';
    var cipher_time =  '';
    var crypted_time = '';
    var cipher_category =  '';
    var crypted_category = '';
    var cipher_SenderId =  '';
    var crypted_SenderId = '';
    var encryptedText ='';


    var pro2 = JSON.parse(MessageData); //for service 
    //var pro2 = (MessageData);         //for service 
    console.log(pro2);
    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;
        cipher_SenderId = crypto.createCipher('aes-256-cbc', key);
        crypted_SenderId = cipher_SenderId.update(SenderId, 'utf-8', 'hex');
        crypted_SenderId += cipher_SenderId.final('hex');

        var indexOfArray = categoryListfromDB.indexOf(crypted_SenderId);
        if (indexOfArray > -1) {
            return Categories.forge().query(function(qb) {
                qb.where({
                    "SenderId": crypted_SenderId
                });
                qb.andWhere({
                    'contact_id': contact_id
                });
            }).fetch().then(function(data) {
                var cat_id = data.get("cat_id");
                console.log("=====================================");
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                console.log("=====================================");
                console.log(a);
                console.log("=====================================");
                console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);
                    cipher_time = crypto.createCipher('aes-256-cbc', key);
                    crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                    crypted_time += cipher_time.final('hex');

                    return ExcelMessages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': crypted_time
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        cipher_message = crypto.createCipher('aes-256-cbc', key);
                        crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                        crypted_message += cipher_message.final('hex');

                        //console.log("cryptedcrypted"+crypted);
                        //return crypted;
                        //console.log("encryptedText ="+ crypted);
                        //if(a[index] =)
                        var ExcelMessagesData = new ExcelMessages({
                            "message": crypted_message,
                            "time": crypted_time,
                            "PhoneNumber": encryptedPhoneNumber,
                            "cat_id": cat_id,
                        });
                        return ExcelMessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });
            }).catch(function(err) {
                return err;
            })
        } else {

            cipher_category = crypto.createCipher('aes-256-cbc', key);
            crypted_category = cipher_category.update(category, 'utf-8', 'hex');
            crypted_category += cipher_category.final('hex');

            var catData = new Categories({
                "contact_id": contact_id,
                "category": crypted_category,
                "SenderId": crypted_SenderId
            });
            return catData.save(null).tap(function(model) {
                return model;
            }).then(function(data) {
                var cat_id = data.get("cat_id");
                console.log("cat_id" + cat_id);
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                console.log(a);
                console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);
                    cipher_time = crypto.createCipher('aes-256-cbc', key);
                    crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                    crypted_time += cipher_time.final('hex');

                    return ExcelMessages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': crypted_time
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        cipher_message = crypto.createCipher('aes-256-cbc', key);
                        crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                        crypted_message += cipher_message.final('hex');

                        var ExcelMessagesData = new ExcelMessages({
                            "message": crypted_message,
                            "time": crypted_time,
                            "PhoneNumber": encryptedPhoneNumber,
                            "cat_id": cat_id,
                        });
                        return ExcelMessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });

            }).catch(function(err) {
                return err;
            });
        }


    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}

exports.ExcelNewAddCatDetails = function(encryptedPhoneNumber,contact_id, MessageData) {
    console.log("add Cat Details service");
    //var key = "supersecretkey";
    var cipher_message =  '';
    var crypted_message = '';
    var cipher_time =  '';
    var crypted_time = '';
    var cipher_category =  '';
    var crypted_category = '';
    var cipher_SenderId =  '';
    var crypted_SenderId = '';

    //var pro2 = JSON.parse(MessageData); //for service 
    var pro2 = (MessageData);         //for service 
    console.log(pro2);

    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;

        cipher_category = crypto.createCipher('aes-256-cbc', key);
        crypted_category = cipher_category.update(category, 'utf-8', 'hex');
        crypted_category += cipher_category.final('hex');

        cipher_SenderId = crypto.createCipher('aes-256-cbc', key);
        crypted_SenderId = cipher_SenderId.update(SenderId, 'utf-8', 'hex');
        crypted_SenderId += cipher_SenderId.final('hex');

        var catData = new Categories({
            "contact_id": contact_id,
            "category": crypted_category,
            "SenderId": crypted_SenderId
        });
        return catData.save(null).tap(function(model) {
            return model;
        }).then(function(data) {
            var cat_id = data.get("cat_id");
            console.log("cat_id" + cat_id);
            var a = elements.messages;
            var b = elements.time;
            var c = a.concat(b);
            console.log(a);
            console.log(b);
            return bPromise.all(c).each(function(item, index) {
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                cipher_time = crypto.createCipher('aes-256-cbc', key);
                crypted_time = cipher_time.update(b[index], 'utf-8', 'hex');
                crypted_time += cipher_time.final('hex');

                return ExcelMessages.forge().query(function(qb) {
                    qb.where({
                        "time": ''
                    });
                    qb.orWhere({
                        'time': crypted_time
                    });
                    qb.del();
                }).fetch().then(function(deleteData) {
                    cipher_message = crypto.createCipher('aes-256-cbc', key);
                    crypted_message = cipher_message.update(a[index], 'utf-8', 'hex');
                    crypted_message += cipher_message.final('hex');

                    var ExcelMessagesData = new ExcelMessages({
                        "message": crypted_message,
                        "time": crypted_time,
                        "PhoneNumber": encryptedPhoneNumber,
                        "cat_id": cat_id,
                    });
                    return ExcelMessagesData.save(null).tap(function(model) {
                        return model;
                    }).then(function(data) {
                        return data;
                    })
                });

            }).then(function(data) {
                return data;
            });
        }).catch(function(err) {
            return err;
        });
    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}

/**
 *   @name : Checking duplicacy of Details from DB
 ***/
exports.find = function(encryptedPhoneNumber) {
    console.log("encryptedPhoneNumber "+encryptedPhoneNumber);
    return Contact.forge().query(function(qb) {
        qb.where({
            "PhoneNumber": encryptedPhoneNumber
        });
    }).fetch(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}


exports.findAdvertisement = function() {
    return AdvertismentTBL.forge().query(function(qb) {
        qb.orderBy('id', 'desc')
        qb.limit(1);
    }).fetch(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}


/**
 *   @name : Checking duplicacy of Details from DB
 ***/
exports.find_cat = function(cat_id) {
    console.log(cat_id);
    //return false;
    return Categories.forge().query(function(qb) {
        qb.where({
            "contact_id": cat_id
        });
    }).fetchAll(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}




/**
*   @name : Updating a Pa catData = new Categories({
                "contact_id":contact_id,
                "category": category,
                "SenderId": SenderId
            });
            return catData.save(null).tap(function (model){
                return model;
            }).then(function(data){
                var cat_id =data.get("cat_id");
                return bPromise.all(elements.messages).each(function(item, index) {
                    var MessagesData = new Messages({
                        "message": item,
                        "cat_id": cat_id,
                    });
                    return MessagesData.save(null).tap(function (model){
                        return model;
                    }).then(function(data){
                        return data;
                    }).catch(function(err){
                        return err;
                    });
                }).then(function(data) {
                    return data;
                })
            }).catch(function(err){
                return err;
            });ssword of Admin & Super Admin in DB
***/
exports.updatingPassword = function(id, password) {
    console.log("service update Password");

    params = {
        "password": password
    }

    var updateParams = {
        patch: true
    }

    var data = params;

    return User.forge().query(function(qb) {
        qb.where('id', id);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}


exports.code_update = function(contact_no, code) {
    var code = (code) ? code : false;
    console.log("The contact no on service page is " + contact_no);
    var datetimeOld = new Date();
    params = {
        "datetimeOld": datetimeOld,
        "code": code
    }
    var updateParams = {
        patch: true
    }

    var data = params;
    return User.forge().query(function(qb) {
        qb.where('contact_no', contact_no);
        qb.orWhere({
            username: contact_no
        })
    }).fetch().then(function(user) {
        return user.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

/**
 *   @name : Updating a Password of Admin & Super Admin Using OTP in DB
 ***/
exports.updatePassword = function(code, password) {
    console.log("service update Password");

    params = {
        "password": password
    }

    var updateParams = {
        patch: true
    }

    var data = params;
    console.log("codeeeeeeeeeeeeeee");
    console.log("codeeeeeeeeeeeeeee = " + code);

    return User.forge().query(function(qb) {
        qb.where('code', code);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

exports.duplicateMobile = function(encryptedPhoneNumber) {
    console.log("encryptedPhoneNumber "+encryptedPhoneNumber);
    return Contact.forge().query(function(qb) {
        qb.where({
            "PhoneNumber": encryptedPhoneNumber
        });
    }).fetch(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}