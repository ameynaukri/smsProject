var User = require('../models/user.model'),
    Contact = require('../models/PhoneNumber.model'),
    Categories = require('../models/Category.model'),
    Messages = require('../models/Message.model'),
    SendMessage = require('../models/SendMessage.model'),
    moment = require('moment');
bPromise = require("bluebird");
var request = require('request');
var crypto = require("crypto")
var key = "supersecretkey";

function encrypt(key, text) {
        var cipher = crypto.createCipher('aes-256-cbc', key);
        var crypted = cipher.update(text, 'utf-8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
}

function decrypt(key, tonumber) {
        var decipher = crypto.createDecipher('aes-256-cbc', key);
        var decrypted = decipher.update(tonumber, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');

        return decrypted;
}

function encrypt_final(key, res2) {
        var cipher = crypto.createCipher('aes-256-cbc', key);
        var crypted = cipher.update(res2, 'utf-8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
}


exports.SendMessage_Insert = function(array_tonumber,message,number,fromnumber) {
    console.log("(array_tonumber[i] "+array_tonumber); 

    var cipher_message = ''; 
    var crypted_message = '';
    var cipher_item = ''; 
    var crypted_item = '';
    var tonumber='';

    return bPromise.all(array_tonumber).each(function(item, index) {
        tonumber = item;
        request("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList="+tonumber+"&msgText="+message+"\n\n\nFrom :"+fromnumber+"&senderId=DATAVL", function(error, response, body) {
                    if (!error && response.statusCode == 200) {
                        console.log(body);
                        
                    }
                })
        
        var text = '"'+ tonumber +'"';
        tonumber = encrypt(key, text);
        var decryptedText = decrypt(key, tonumber);
        console.log("decryptedText After "+decryptedText);
        var res2 = decryptedText.replace(/"/g, "");
        console.log("res "+res2);
        tonumber = encrypt_final(key, res2);
        console.log("tonumber------------------ "+tonumber);

        cipher_message = crypto.createCipher('aes-256-cbc', key);
        crypted_message = cipher_message.update(message, 'utf-8', 'hex');
        crypted_message += cipher_message.final('hex');

        console.log("crypted_message "+crypted_message);
        console.log("item "+item);
        var MessagesData = new SendMessage({
            "message": crypted_message,
            "tonumber": tonumber,
            "fromnumber": number,
        });
        return MessagesData.save(null).tap(function (model){
            return model;
        }).then(function(data){
            return data;
        }).catch(function(err){
            return err;
        })
    }); 
};

exports.find = function(crypted_number){
    console.log("PhoneNumber "+crypted_number);
    return Contact.forge().query(function (qb) {
        qb.where({"PhoneNumber":crypted_number});
    }).fetch(function(data){
        return data;
    }).catch(function(err){
        return err;
    })
} 

exports.addReg = function(params) {
    console.log("addReg");
    var Contactdata = new Contact({
        "FullName": (params.FullName) ? params.FullName : false,
        "LastName": (params.LastName) ? params.LastName : false,
        "MessageLimit": (params.MessageLimit) ? params.MessageLimit : false,
        "PhoneNumber": (params.PhoneNumber) ? params.PhoneNumber : false,
        "StartDate": (params.StartDate) ? params.StartDate : false,
        "EndDate": (params.EndDate) ? params.EndDate : false,
        "Type": "1",
    });
    return Contactdata.save(null).tap(function(model) {
        Contactdata = model;
        return Contactdata;
    }).then(function(Contactdata) {
        return Contactdata;
    }).catch(function(err) {
        return err;
    });

}

exports.UpdateReg = function(params) {

    var PhoneNumber = (params.PhoneNumber) ? params.PhoneNumber : false;

    params = {
        "FullName": (params.FullName) ? params.FullName : false,
        "LastName": (params.LastName) ? params.LastName : false,
        "MessageLimit": (params.MessageLimit) ? params.MessageLimit : false,
        //"PhoneNumber": (params.PhoneNumber) ? params.PhoneNumber : false,
        "StartDate": (params.StartDate) ? params.StartDate : false,
        "EndDate": (params.EndDate) ? params.EndDate : false,
        "Type": "1",
    }
    var updateParams = {
        patch: true
    }

    var data = params;

    return Contact.forge().query(function(qb) {
        qb.where('PhoneNumber', PhoneNumber);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}    


exports.addPhoneNumber = function(PhoneNumber) {
    console.log("add Details service");
    var date = moment(new Date()).format("YYYY-MM-DD");
    var Type = 2;
    var PhoneNumberData = new Contact({
        "PhoneNumber": PhoneNumber,
        "Type": Type,
    });

    return PhoneNumberData.save(null).tap(function(PhoneNumberData) {
        return PhoneNumberData;
    }).then(function(PhoneNumberData) {
        return PhoneNumberData;
    }).catch(function(err) {
        return err;
    });
}

/**
 *   @name : Adding Details in DB
 *   @params : message, contact
 ***/
exports.addCatDetails = function(contact_id, MessageData, categoryListfromDB) {
    //console.log("add Cat Details service");
    //console.log(categoryListfromDB);

    var pro2 = JSON.parse(MessageData); //for service 
    //var pro2 = (MessageData);         //for service 

    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;

        var indexOfArray = categoryListfromDB.indexOf(SenderId);
        if (indexOfArray > -1) {
            return Categories.forge().query(function(qb) {
                qb.where({
                    "SenderId": SenderId
                });
                qb.andWhere({
                    'contact_id': contact_id
                });
            }).fetch().then(function(data) {
                var cat_id = data.get("cat_id");
                console.log("cat_id" + cat_id);
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                console.log(a);
                console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);

                    return Messages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': b[index]
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        //if(a[index] =)
                        var MessagesData = new Messages({
                            "message": a[index],
                            "time": b[index],
                            "cat_id": cat_id,
                        });
                        return MessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });
            }).catch(function(err) {
                return err;
            })
        } else {

            var catData = new Categories({
                "contact_id": contact_id,
                "category": category,
                "SenderId": SenderId
            });
            return catData.save(null).tap(function(model) {
                return model;
            }).then(function(data) {
                var cat_id = data.get("cat_id");
                console.log("cat_id" + cat_id);
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);
                console.log(a);
                console.log(b);
                return bPromise.all(c).each(function(item, index) {
                    var a = elements.messages;
                    var b = elements.time;
                    var c = a.concat(b);

                    return Messages.forge().query(function(qb) {
                        qb.where({
                            "time": ''
                        });
                        qb.orWhere({
                            'time': b[index]
                        });
                        qb.del();
                    }).fetch().then(function(deleteData) {
                        //if(a[index] =)
                        var MessagesData = new Messages({
                            "message": a[index],
                            "time": b[index],
                            "cat_id": cat_id,
                        });
                        return MessagesData.save(null).tap(function(model) {
                            return model;
                        }).then(function(data) {
                            return data;
                        })
                    });

                }).then(function(data) {
                    return data;
                });

            }).catch(function(err) {
                return err;
            });
        }


    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}


/**
 *   @name : Checking duplicacy of Details from DB
 ***/
exports.find = function(PhoneNumber) {
    return Contact.forge().query(function(qb) {
        qb.where({
            "PhoneNumber": PhoneNumber
        });
    }).fetch(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}


/**
 *   @name : Checking duplicacy of Details from DB
 ***/
exports.find_cat = function(cat_id) {
    console.log(cat_id);
    //return false;
    return Categories.forge().query(function(qb) {
        qb.where({
            "contact_id": cat_id
        });
    }).fetchAll(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}


exports.NewAddCatDetails = function(contact_id, MessageData) {
    console.log("add Cat Details service");

    var pro2 = JSON.parse(MessageData); //for service 
    //var pro2 = (MessageData);         //for service 

    return bPromise.all(pro2).each(function(elements) {
        var category = elements.Name;
        var SenderId = elements.SenderId;

        var catData = new Categories({
            "contact_id": contact_id,
            "category": category,
            "SenderId": SenderId
        });
        return catData.save(null).tap(function(model) {
            return model;
        }).then(function(data) {
            var cat_id = data.get("cat_id");
            console.log("cat_id" + cat_id);
            var a = elements.messages;
            var b = elements.time;
            var c = a.concat(b);
            console.log(a);
            console.log(b);
            return bPromise.all(c).each(function(item, index) {
                var a = elements.messages;
                var b = elements.time;
                var c = a.concat(b);

                return Messages.forge().query(function(qb) {
                    qb.where({
                        "time": ''
                    });
                    qb.orWhere({
                        'time': b[index]
                    });
                    qb.del();
                }).fetch().then(function(deleteData) {
                    //if(a[index] =)
                    var MessagesData = new Messages({
                        "message": a[index],
                        "time": b[index],
                        "cat_id": cat_id,
                    });
                    return MessagesData.save(null).tap(function(model) {
                        return model;
                    }).then(function(data) {
                        return data;
                    })
                });

            }).then(function(data) {
                return data;
            });
        }).catch(function(err) {
            return err;
        });
    }).then(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    });
}

/**
*   @name : Updating a Pa catData = new Categories({
                "contact_id":contact_id,
                "category": category,
                "SenderId": SenderId
            });
            return catData.save(null).tap(function (model){
                return model;
            }).then(function(data){
                var cat_id =data.get("cat_id");
                return bPromise.all(elements.messages).each(function(item, index) {
                    var MessagesData = new Messages({
                        "message": item,
                        "cat_id": cat_id,
                    });
                    return MessagesData.save(null).tap(function (model){
                        return model;
                    }).then(function(data){
                        return data;
                    }).catch(function(err){
                        return err;
                    });
                }).then(function(data) {
                    return data;
                })
            }).catch(function(err){
                return err;
            });ssword of Admin & Super Admin in DB
***/
exports.updatingPassword = function(id, password) {
    console.log("service update Password");

    params = {
        "password": password
    }

    var updateParams = {
        patch: true
    }

    var data = params;

    return User.forge().query(function(qb) {
        qb.where('id', id);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}


exports.code_update = function(contact_no, code) {
    var code = (code) ? code : false;
    console.log("The contact no on service page is " + contact_no);
    var datetimeOld = new Date();
    params = {
        "datetimeOld": datetimeOld,
        "code": code
    }
    var updateParams = {
        patch: true
    }

    var data = params;
    return User.forge().query(function(qb) {
        qb.where('contact_no', contact_no);
        qb.orWhere({
            username: contact_no
        })
    }).fetch().then(function(user) {
        return user.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

/**
 *   @name : Updating a Password of Admin & Super Admin Using OTP in DB
 ***/
exports.updatePassword = function(code, password) {
    console.log("service update Password");

    params = {
        "password": password
    }

    var updateParams = {
        patch: true
    }

    var data = params;
    console.log("codeeeeeeeeeeeeeee");
    console.log("codeeeeeeeeeeeeeee = " + code);

    return User.forge().query(function(qb) {
        qb.where('code', code);
    }).fetch().then(function(updatePass) {
        return updatePass.save(data, updateParams);
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

exports.duplicateMobile = function(PhoneNumber) {
    return Contact.forge().query(function(qb) {
        qb.where({
            "PhoneNumber": PhoneNumber
        });
    }).fetch(function(data) {
        return data;
    }).catch(function(err) {
        return err;
    })
}